create table users (
	id serial primary key,
	name varchar(255),
	email varchar(255)
);

select * from users;
